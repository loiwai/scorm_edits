var scorm = {
  apiHandle: null,
  initialized: false,
  terminated: false,

  findAPI: function(win) {
    var maxTries = 500;
    while ((win.API == null) && (win.parent != null) && (win.parent != win) && maxTries > 0) {
      maxTries--;
      win = win.parent;
    }
    return win.API;
  },

  getAPI: function() {
    if (this.apiHandle == null) {
      this.apiHandle = this.findAPI(window);
    }
    return this.apiHandle;
  },

  init: function() {
    var api = this.getAPI();
    if (api && api.LMSInitialize && !this.initialized) {
      var result = api.LMSInitialize("");
      this.initialized = (result === "true");
    }
  },

  finish: function() {
    var api = this.getAPI();
    if (api && api.LMSFinish && this.initialized && !this.terminated) {
      api.LMSCommit("");
      api.LMSFinish("");
      this.terminated = true;
    }
  },

  set: function(name, value) {
    var api = this.getAPI();
    if (api && api.LMSSetValue && this.initialized) {
      api.LMSSetValue(name, value);
    }
  },

  get: function(name) {
    var api = this.getAPI();
    if (api && api.LMSGetValue && this.initialized) {
      return api.LMSGetValue(name);
    }
    return "";
  },

  commit: function() {
    var api = this.getAPI();
    if (api && api.LMSCommit && this.initialized) {
      api.LMSCommit("");
    }
  }
};
