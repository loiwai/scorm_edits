var scorm = {
  api: null,

  init: function () {
    this.api = this.getAPI();
    if (this.api) {
      this.api.Initialize("");
    }
  },

  getAPI: function () {
    var win = window;
    while (win) {
      if (win.API_1484_11) return win.API_1484_11;
      win = win.parent;
    }
    return null;
  },

  set: function (key, value) {
    if (this.api) this.api.SetValue(key, value);
  },

  commit: function () {
    if (this.api) this.api.Commit("");
  },

  complete: function (score) {
    this.set("cmi.score.raw", score);
    this.set("cmi.score.max", "100");
    this.set("cmi.completion_status", "completed");
    this.set("cmi.success_status", "passed");
    this.commit();
  },

  finish: function () {
    if (this.api) {
      this.api.Terminate("");
    }
  }
};
