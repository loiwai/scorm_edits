(function(){
  const state={sections:['v1','q1','v2','q2','v3','q3','cert'],idx:0,learnerName:'Learner',suspend:{}};
  function save(){try{SCORM2004.SetValue('cmi.suspend_data',JSON.stringify({idx:state.idx,suspend:state.suspend}));SCORM2004.Commit();}catch(e){}}
  function load(){try{const s=SCORM2004.GetValue('cmi.suspend_data');if(s){const o=JSON.parse(s);if(o&&typeof o.idx==='number'){state.idx=o.idx;state.suspend=o.suspend||{};}}}catch(e){}}
  function init(){SCORM2004.Initialize(); let n=SCORM2004.GetValue('cmi.learner_name'); state.learnerName=n||'Learner'; document.querySelectorAll('.learner-name').forEach(el=>el.textContent=state.learnerName); const c=SCORM2004.GetValue('cmi.completion_status'); if(!c||c==='unknown'){SCORM2004.SetValue('cmi.completion_status','incomplete');SCORM2004.SetValue('cmi.success_status','unknown');SCORM2004.Commit();} load();}
  function show(i){state.idx=i; document.querySelectorAll('.section').forEach(s=>s.classList.remove('active')); const id=state.sections[i]; const el=document.getElementById(id); if(el) el.classList.add('active'); document.getElementById('progressText').textContent=`${i+1} / ${state.sections.length}`; document.getElementById('backBtn').disabled=(i===0); save(); if(id==='cert'){SCORM2004.SetValue('cmi.score.scaled','1');SCORM2004.SetValue('cmi.success_status','passed');SCORM2004.SetValue('cmi.completion_status','completed');SCORM2004.Commit();}}
  function next(){ if(state.idx<state.sections.length-1) show(state.idx+1);} function back(){ if(state.idx>0) show(state.idx-1);} 
  function bindVideo(sectionId,seconds){ const sec=document.getElementById(sectionId); const cont=sec.querySelector('.continue'); cont.disabled=true; const video=sec.querySelector('video'); const progressFill=sec.querySelector('.progress > div'); if(video){ video.controls=true; video.playbackRate=1.0; let last=0,seeking=false; video.addEventListener('ratechange',()=>{video.playbackRate=1.0;}); video.addEventListener('seeking',()=>{seeking=true; if(video.currentTime>last+0.5) video.currentTime=last;}); video.addEventListener('timeupdate',()=>{ if(seeking){seeking=false;return;} if(video.currentTime>last) last=video.currentTime; const dur=video.duration||seconds; const pct=Math.min(100,Math.round((last/dur)*100)); progressFill.style.width=pct+'%';}); video.addEventListener('ended',()=>{progressFill.style.width='100%'; cont.disabled=false;}); setTimeout(()=>{ video.play().catch(()=>{}); },300);} else { let t=0; const iv=setInterval(()=>{ t+=0.2; const pct=Math.min(100,Math.round((t/seconds)*100)); progressFill.style.width=pct+'%'; if(t>=seconds){clearInterval(iv); cont.disabled=false;} },200);}}
  function bindQuiz(sectionId, answers){
    const sec = document.getElementById(sectionId);
    const form = sec.querySelector('form');
    const fb = sec.querySelector('.feedback');
    const cont = sec.querySelector('.continue');
    cont.disabled = true;

    function validate(){
      fb.textContent = '';
      // Build set of radio group names present in THIS form
      const radios = Array.from(form.querySelectorAll('input[type="radio"]'));
      const groups = Array.from(new Set(radios.map(r => r.name)));
      // Ensure every group has one checked
      for(const name of groups){
        const chosen = form.querySelector('input[name="'+name+'"]:checked');
        if(!chosen){ fb.textContent = 'Please answer all questions.'; fb.className = 'feedback err'; return false; }
        // If we have an expected answer for this group, check it
        if(answers && answers[name] && chosen.value !== answers[name]){
          fb.textContent = 'One or more answers are incorrect. Please try again.'; fb.className = 'feedback err'; return false;
        }
      }
      fb.textContent = 'All correct! You may continue.'; fb.className='feedback ok';
      return true;
    }

    // Live validation on change (helps some LMS wrappers)
    form.addEventListener('change', ()=>{
      // Do not auto-enable Continue until they press Check once
      validate();
    });

    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      if(validate()){
        cont.disabled = false;
      }
    });
  }
window.addEventListener('DOMContentLoaded',()=>{ init(); document.getElementById('backBtn').addEventListener('click',back); document.getElementById('nextBtn').addEventListener('click',()=>{ const sec=document.querySelector('.section.active'); const gate=sec.querySelector('.continue'); if(gate&&gate.disabled) return; next(); }); bindVideo('v1',5); bindQuiz('q1',{'q1a':'b','q1b':'c'}); bindVideo('v2',5); bindQuiz('q2',{'q2a':'a','q2b':'d'}); bindVideo('v3',5); bindQuiz('q3',{'q3a':'b'}); const d=new Date(); document.getElementById('certName').textContent=state.learnerName; document.getElementById('certDate').textContent=d.toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'}); show(state.idx); }); window.addEventListener('beforeunload',()=>{ save(); SCORM2004.Commit(); SCORM2004.Terminate(); });})();